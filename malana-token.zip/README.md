# 💰 MALANA Token
Token edukasi berbasis Hardhat, tidak butuh BNB, dan bisa dijalankan lokal.

## Cara Jalankan Lokal
```bash
git clone <repo-url>
cd malana-token
npm install
npx hardhat node
npx hardhat run scripts/deploy.js --network localhost
```
