const hre = require("hardhat");

async function main() {
  const MalanaToken = await hre.ethers.getContractFactory("MalanaToken");
  const malana = await MalanaToken.deploy(1000000); // 1 juta MALANA

  await malana.deployed();

  console.log("MalanaToken deployed to:", malana.address);
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
